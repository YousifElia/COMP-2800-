import java.awt.*;
import java.awt.image.*;

public class Player extends GameObject {

	private Animator idleAnimator;

	public Player(float x, float y) {
		super(x, y, 64, 64);
		BufferedImage[] idleFrames = Resources.spriteSheet.getImagesFrom(0, 6);
		idleAnimator = new Animator(idleFrames, 0, 5);
	}
	
	@Override
	public void tick() {
		if(GameCanvas.keyboard.up) y += -2;
		if(GameCanvas.keyboard.down) y += 2;
		if(GameCanvas.keyboard.right) x += 2;
		if(GameCanvas.keyboard.left) x += -2;

		idleAnimator.tick();
	}

	@Override
	public void render(Graphics2D g2d) {
		g2d.drawImage(idleAnimator.currentFrame, (int) x, (int) y, (int) width, (int) height, null);
	}

	@Override
	public Rectangle rect() {
		return new Rectangle((int) x + 10, (int) y + 10, (int) width - 20, (int) height - 20);
	}
}
