import javax.swing.*;

public class Main {

	public static void main(String[] args) {
		JFrame mainWindow = new JFrame("Lab 5 Demo");
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.setSize(GameCanvas.GAME_WIDTH, GameCanvas.GAME_HEIGHT);
		mainWindow.setLocationRelativeTo(null);
		mainWindow.setResizable(false);
		
		GameCanvas gameCanvas = new GameCanvas();
		mainWindow.add(gameCanvas);
		mainWindow.setVisible(true);

		gameCanvas.start();
	}
}
