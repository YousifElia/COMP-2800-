public class Resources {
	
	public static SpriteSheet spriteSheet = new SpriteSheet("res/SpriteSheet.png", 8, 8, 64, 64);

}
