import java.awt.*;
import java.awt.image.*;

public class GameCanvas extends Canvas implements Runnable {

	private Thread thread;
	private BufferStrategy bs;

	public static final int GAME_WIDTH = 782, GAME_HEIGHT = 548;  

	private Player player = new Player(0, 0);

	public static GameManager gameManager = new GameManager();
	public static Keyboard keyboard = new Keyboard();

	public GameCanvas() {
		gameManager.addGameObject(player);

		this.addKeyListener(keyboard);
	}

	public void start() {
		this.requestFocus();
		this.createBufferStrategy(2);
		bs = this.getBufferStrategy();
		thread = new Thread(this, "Game Thread");
		thread.start();
	}

	@Override
	public void run() {
		long lastTime = System.nanoTime();
        long timer = System.currentTimeMillis();
        double delta = 0;
		final int UPS_CAP = 60;

        while (true) {
            long now = System.nanoTime();
            delta += (now - lastTime) / (double) (1000000000 / UPS_CAP);
            lastTime = now;

            while (delta >= 1) {
                tick();
                delta--;
            }
            render();
            if (System.currentTimeMillis() - timer > 1000) timer += 1000;
        }
	}

	private void tick() {
		gameManager.tick();
	}
	
	public void render() {
		Graphics2D g2d = (Graphics2D) bs.getDrawGraphics();
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g2d.setColor(Color.black);
		g2d.fillRect(0, 0, this.getWidth(), this.getHeight());

		gameManager.render(g2d);
		
		g2d.dispose();
		bs.show();
	}

}

