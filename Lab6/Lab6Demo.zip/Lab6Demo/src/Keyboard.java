import java.awt.event.*;

public class Keyboard extends KeyAdapter {

	public boolean left = false, right = false, up = false, down = false;

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_A) left = true;
		else if(e.getKeyCode() == KeyEvent.VK_D) right = true;
		else if(e.getKeyCode() == KeyEvent.VK_W) up = true;
		else if(e.getKeyCode() == KeyEvent.VK_S) down = true;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_A) left = false;
		else if(e.getKeyCode() == KeyEvent.VK_D) right = false;
		else if(e.getKeyCode() == KeyEvent.VK_W) up = false;
		else if(e.getKeyCode() == KeyEvent.VK_S) down = false;
	}
}
